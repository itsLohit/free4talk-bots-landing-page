// ===========================
// INITIALIZATION
// ===========================
document.addEventListener('DOMContentLoaded', async () => {
    await loadSettings();
    setupEventListeners();
});

// ===========================
// LOAD SETTINGS
// ===========================
async function loadSettings() {
    // Load premium status
    const isPremium = await getPremiumStatus();
    updatePremiumUI(isPremium);
    
    // Load bot status
    const settings = await chrome.storage.local.get(['botEnabled', 'apiKey', 'authorizedUsers', 'stats']);
    
    // Bot enabled/disabled
    const botEnabled = settings.botEnabled !== undefined ? settings.botEnabled : true;
    document.getElementById('bot-enabled').checked = botEnabled;
    updateBotIndicator(botEnabled);
    
    // API key
    if (settings.apiKey) {
        document.getElementById('api-key-input').value = settings.apiKey;
    }
    
    // Authorized users
    const users = settings.authorizedUsers || ['Aang', 'Starlight', 'Rudra', 'Sanjay Kumar', 'Duvarakesh Ravi', 'Deep'];
    renderUsersList(users);
    
    // Stats
    if (settings.stats) {
        updateStats(settings.stats);
    }
}

// ===========================
// EVENT LISTENERS
// ===========================
function setupEventListeners() {
    // Bot toggle
    document.getElementById('bot-toggle').addEventListener('click', () => {
        const checkbox = document.getElementById('bot-enabled');
        checkbox.checked = !checkbox.checked;
        toggleBot(checkbox.checked);
    });
    
    document.getElementById('bot-enabled').addEventListener('change', (e) => {
        toggleBot(e.target.checked);
    });
    
    // License activation
    document.getElementById('activate-btn').addEventListener('click', activateLicense);
    document.getElementById('deactivate-btn').addEventListener('click', deactivateLicense);
    
    // API key
    document.getElementById('save-api-btn').addEventListener('click', saveApiKey);
    
    // Users
    document.getElementById('add-user-btn').addEventListener('click', addUser);
    document.getElementById('new-user-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addUser();
    });
}

// ===========================
// BOT CONTROL
// ===========================
async function toggleBot(enabled) {
    await chrome.storage.local.set({ botEnabled: enabled });
    updateBotIndicator(enabled);
    
    // Notify background script
    chrome.runtime.sendMessage({ type: 'BOT_STATUS_CHANGED', data: { enabled } });
    
    console.log(`Bot ${enabled ? 'enabled' : 'disabled'}`);
}

function updateBotIndicator(enabled) {
    const indicator = document.getElementById('bot-indicator');
    if (enabled) {
        indicator.classList.remove('off');
    } else {
        indicator.classList.add('off');
    }
}

// ===========================
// PREMIUM MANAGEMENT
// ===========================
async function getPremiumStatus() {
    return new Promise(resolve => {
        chrome.runtime.sendMessage({ type: "CHECK_PREMIUM" }, res => {
            resolve(res.isPremium);
        });
    });
}

function updatePremiumUI(isPremium) {
    const badge = document.getElementById('premium-badge');
    const licenseForm = document.getElementById('license-form');
    const premiumSection = document.getElementById('premium-section');
    
    if (isPremium) {
        badge.textContent = '✨ Premium';
        badge.className = 'status-badge status-premium';
        licenseForm.classList.add('hidden');
        premiumSection.classList.remove('hidden');
    } else {
        badge.textContent = 'Free';
        badge.className = 'status-badge status-free';
        licenseForm.classList.remove('hidden');
        premiumSection.classList.add('hidden');
    }
}

async function activateLicense() {
    const key = document.getElementById('license-input').value.trim();
    if (!key) {
        alert('Please paste your license key');
        return;
    }
    
    chrome.runtime.sendMessage({ type: 'ACTIVATE_LICENSE', data: { key } }, res => {
        alert(res.message);
        if (res.success) {
            updatePremiumUI(true);
            document.getElementById('license-input').value = '';
        }
    });
}

async function deactivateLicense() {
    if (!confirm('Are you sure you want to deactivate premium?')) return;
    
    chrome.runtime.sendMessage({ type: 'DEACTIVATE_LICENSE' }, res => {
        alert(res.message);
        updatePremiumUI(false);
    });
}

// ===========================
// API KEY MANAGEMENT
// ===========================
async function saveApiKey() {
    const apiKey = document.getElementById('api-key-input').value.trim();
    
    if (!apiKey) {
        alert('Please enter your API key');
        return;
    }
    
    if (!apiKey.startsWith('AIzaSy')) {
        alert('Invalid API key format. Should start with "AIzaSy"');
        return;
    }
    
    await chrome.storage.local.set({ apiKey: apiKey });
    
    // Notify background script
    chrome.runtime.sendMessage({ type: 'API_KEY_UPDATED', data: { apiKey } });
    
    alert('✅ API key saved successfully!');
}

// ===========================
// USER MANAGEMENT
// ===========================
function renderUsersList(users) {
    const listElement = document.getElementById('users-list');
    listElement.innerHTML = '';
    
    if (users.length === 0) {
        listElement.innerHTML = '<div class="user-item">No authorized users</div>';
        return;
    }
    
    users.forEach(user => {
        const item = document.createElement('div');
        item.className = 'user-item';
        item.innerHTML = `
            <span>${user}</span>
            <button class="user-remove" data-user="${user}">✕</button>
        `;
        listElement.appendChild(item);
    });
    
    // Add remove listeners
    document.querySelectorAll('.user-remove').forEach(btn => {
        btn.addEventListener('click', () => removeUser(btn.dataset.user));
    });
}

async function addUser() {
    const input = document.getElementById('new-user-input');
    const username = input.value.trim();
    
    if (!username) {
        alert('Please enter a username');
        return;
    }
    
    const result = await chrome.storage.local.get('authorizedUsers');
    let users = result.authorizedUsers || [];
    
    if (users.includes(username)) {
        alert('User already authorized');
        return;
    }
    
    users.push(username);
    await chrome.storage.local.set({ authorizedUsers: users });
    
    // Notify background script
    chrome.runtime.sendMessage({ type: 'USERS_UPDATED', data: { users } });
    
    renderUsersList(users);
    input.value = '';
}

async function removeUser(username) {
    const result = await chrome.storage.local.get('authorizedUsers');
    let users = result.authorizedUsers || [];
    
    users = users.filter(u => u !== username);
    await chrome.storage.local.set({ authorizedUsers: users });
    
    // Notify background script
    chrome.runtime.sendMessage({ type: 'USERS_UPDATED', data: { users } });
    
    renderUsersList(users);
}

// ===========================
// STATS UPDATE
// ===========================
function updateStats(stats) {
    const statElements = document.querySelectorAll('.stat-value');
    if (statElements[0]) statElements[0].textContent = stats.songsPlayed || 0;
    if (statElements[1]) statElements[1].textContent = stats.commandsProcessed || 0;
}
