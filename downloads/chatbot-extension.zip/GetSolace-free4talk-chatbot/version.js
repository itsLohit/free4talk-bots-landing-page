// ============================================================================
// VERSION.JS - GetSolace Free4Talk Chat Bot
// Central version management
// ============================================================================

const VERSION_INFO = {
  // Version number (Semantic Versioning)
  version: '1.0.0',
  
  // Build info
  buildDate: '2025-11-13',
  buildNumber: 1,
  
  // Release info
  releaseType: 'stable', // 'alpha', 'beta', 'rc', 'stable'
  releaseNotes: 'Initial stable release with server-side license validation',
  
  // Compatibility
  minWorkerVersion: '1.0.0',
  manifestVersion: 3,
  
  // Features in this version
  features: [
    'Server-side license validation',
    'KV persistent storage',
    'Device limit enforcement',
    'Gemini AI integration',
    'Profile management',
    'Person facts memory',
    'Auto-response system'
  ],
  
  // API endpoints
  endpoints: {
    licenseServer: 'https://license-server.getsolace-india.workers.dev',
    geminiApi: 'https://generativelanguage.googleapis.com/v1beta'
  }
};

// Export for use in extension
if (typeof module !== 'undefined' && module.exports) {
  module.exports = VERSION_INFO;
}
