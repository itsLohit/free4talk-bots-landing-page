document.addEventListener('DOMContentLoaded', () => {
  initPopup();
});

async function initPopup() {
  bindUI();
  await loadInitial();
  initPersonFactsUI();
  await loadProfilesDropdown();
}

function bindUI() {
  document.getElementById('saveBtn').addEventListener('click', saveConfiguration);
  document.getElementById('saveProfileBtn').addEventListener('click', saveProfile);
  document.getElementById('loadProfileBtn').addEventListener('click', loadProfile);
  document.getElementById('generatePersonaBtn').addEventListener('click', generatePersona);
  document.getElementById('activateLicenseBtn').addEventListener('click', activateLicense);
  document.getElementById('deactivateLicenseBtn').addEventListener('click', deactivateLicense);
  document.getElementById('checkPremium').addEventListener('click', checkPremium);
}

function initPersonFactsUI() {
  const addBtn = document.getElementById('addPersonFactBtn');
  const factsList = document.getElementById('factsList');
  const textarea = document.getElementById('personFacts');

  addBtn.addEventListener('click', () => {
    const name = document.getElementById('newPersonName').value.trim();
    const fact = document.getElementById('newPersonFact').value.trim();
    if (!name || !fact) return alert('Enter both name and fact');
    addPersonFact(name, fact);
    document.getElementById('newPersonName').value = '';
    document.getElementById('newPersonFact').value = '';
  });

  // load from JSON on init
  try {
    const stored = JSON.parse(textarea.value || '{}');
    for (const [n, f] of Object.entries(stored)) {
      addPersonFact(n, f);
    }
  } catch (e) { console.warn('Invalid stored facts'); }

  function addPersonFact(name, fact) {
    const item = document.createElement('div');
    item.className = 'fact-item';
    item.style = "display:flex; align-items:center; gap:8px; margin-top:6px;";
    item.innerHTML = `
      <input type="text" class="fact-name" value="${name}" style="flex:1; padding:5px; border-radius:6px; border:1px solid #ccc;">
      <input type="text" class="fact-value" value="${fact}" style="flex:2; padding:5px; border-radius:6px; border:1px solid #ccc;">
      <button class="btn-secondary remove-fact" style="padding:4px 8px;">✕</button>
    `;
    factsList.appendChild(item);
    updateTextarea();

    item.querySelector('.remove-fact').addEventListener('click', () => {
      item.remove();
      updateTextarea();
    });
    item.querySelector('.fact-name').addEventListener('input', updateTextarea);
    item.querySelector('.fact-value').addEventListener('input', updateTextarea);
  }

  function updateTextarea() {
    const entries = {};
    factsList.querySelectorAll('.fact-item').forEach(div => {
      const n = div.querySelector('.fact-name').value.trim();
      const f = div.querySelector('.fact-value').value.trim();
      if (n && f) entries[n] = f;
    });
    textarea.value = JSON.stringify(entries, null, 2);
  }
}


async function loadInitial() {
  const res = await new Promise(r => chrome.runtime.sendMessage({ type: 'GET_CONFIG' }, r));
  if (res && res.success) {
    const cfg = res.config;
    document.getElementById('geminiApiKey').value = cfg.geminiApiKey || '';
    document.getElementById('botUsername').value = cfg.botUsername || '';
    document.getElementById('botPersonaPrompt').value = cfg.botPersonaPrompt || '';
    document.getElementById('ignoreSelfMessages').checked = cfg.ignoreSelfMessages ?? true;
    document.getElementById('replyToPM').checked = cfg.replyToPM ?? true;
    document.getElementById('replyWithReaction').checked = cfg.replyWithReaction ?? true;
    document.getElementById('characterLimit').value = cfg.characterLimit || 120;
    document.getElementById('friendsList').value = (cfg.friendsList || []).join(', ');
    document.getElementById('personFacts').value = JSON.stringify(cfg.personFacts || {}, null, 2);
  }
  await checkPremium();
  await loadProfilesDropdown();
}

async function saveConfiguration() {
  let facts = {};
  try {
    facts = JSON.parse(document.getElementById('personFacts').value || '{}');
  } catch (e) {
    showStatus('❌ Invalid JSON in Person Facts', 'error');
    return;
  }

  const cfg = {
    geminiApiKey: document.getElementById('geminiApiKey').value.trim(),
    botUsername: document.getElementById('botUsername').value.trim(),
    botPersonaPrompt: document.getElementById('botPersonaPrompt').value.trim(),
    ignoreSelfMessages: document.getElementById('ignoreSelfMessages').checked,
    replyToPM: document.getElementById('replyToPM').checked,
    replyWithReaction: document.getElementById('replyWithReaction').checked,
    characterLimit: parseInt(document.getElementById('characterLimit').value.trim()) || 120,
    friendsList: document.getElementById('friendsList').value.split(',').map(x => x.trim()).filter(Boolean),
    personFacts: facts
  };

  chrome.runtime.sendMessage({ type: 'UPDATE_CONFIG', data: cfg }, (res) => {
    if (res && res.success) showStatus('✅ Configuration saved', 'success');
    else showStatus('❌ Save failed', 'error');
  });
}

function showStatus(msg, type = 'info') {
  const el = document.getElementById('statusMessage');
  el.textContent = msg;
  el.style.color = type === 'error' ? 'red' : type === 'success' ? 'green' : 'black';
  setTimeout(() => { el.textContent = ''; }, 3000);
}

// Profiles
async function loadProfilesDropdown() {
  const res = await new Promise(r => chrome.runtime.sendMessage({ type: 'GET_CONFIG' }, r));
  const selector = document.getElementById('profileSelector');
  selector.innerHTML = '';
  const profiles = (res && res.profiles) ? res.profiles : {};
  Object.keys(profiles).forEach(name => {
    const opt = document.createElement('option');
    opt.value = name; opt.textContent = name;
    selector.appendChild(opt);
  });
}

async function saveProfile() {
  const name = prompt('Profile name:');
  if (!name) return;
  const profile = {
    geminiApiKey: document.getElementById('geminiApiKey').value.trim(),
    botUsername: document.getElementById('botUsername').value.trim(),
    botPersonaPrompt: document.getElementById('botPersonaPrompt').value.trim(),
    ignoreSelfMessages: document.getElementById('ignoreSelfMessages').checked
  };
  chrome.runtime.sendMessage({ type: 'SAVE_PROFILE', name, profile }, (res) => {
    if (res && res.success) { showStatus('✅ Profile saved', 'success'); loadProfilesDropdown(); }
    else showStatus('❌ Failed to save profile', 'error');
  });
}

async function loadProfile() {
  const selector = document.getElementById('profileSelector');
  const name = selector.value;
  if (!name) return alert('Select profile');
  chrome.runtime.sendMessage({ type: 'LOAD_PROFILE', name }, (res) => {
    if (res && res.success) {
      showStatus('📂 Profile loaded', 'success');
      setTimeout(() => location.reload(), 600);
    } else showStatus('⚠️ ' + (res.error || 'Load failed'), 'error');
  });
}

// Persona generator (premium)
async function generatePersona() {
  const examples = document.getElementById('exampleMessages').value.trim();
  if (!examples) return alert('Paste example messages first');
  document.getElementById('generatePersonaBtn').textContent = 'Generating...';
  chrome.runtime.sendMessage({ type: 'GENERATE_PERSONA', examples }, (res) => {
    document.getElementById('generatePersonaBtn').textContent = '✨ Generate Persona';
    if (res && res.success) {
      document.getElementById('botPersonaPrompt').value = res.persona;
      showStatus('✅ Persona generated', 'success');
    } else {
      if (res && res.error === 'premium_required') showStatus('🔒 Premium required for persona generation', 'error');
      else showStatus('❌ Persona generation failed', 'error');
    }
  });
}

// License handling
async function activateLicense() {
  const key = prompt('Paste your license key:');
  if (!key) return;
  chrome.runtime.sendMessage({ type: 'ACTIVATE_LICENSE', key }, (res) => {
    if (res && res.success) {
      showStatus(res.message || 'Activated', 'success');
      checkPremium();
    } else showStatus(res.message || 'Activation failed', 'error');
  });
}

async function deactivateLicense() {
  chrome.runtime.sendMessage({ type: 'DEACTIVATE_LICENSE' }, (res) => {
    if (res && res.success) {
      showStatus(res.message, 'success');
      checkPremium();
    }
  });
}

async function checkPremium() {
  chrome.runtime.sendMessage({ type: 'CHECK_PREMIUM' }, (res) => {
    const btn = document.getElementById('checkPremium');
    const tag = document.getElementById('premiumTag');
    const premiumSection = document.getElementById('premiumSection');

    if (res && res.isPremium) {
      btn.textContent = 'Premium ✓';
      tag.textContent = 'Universal Chat Bot — Premium Active';
      tag.style.background = 'linear-gradient(135deg, #ffd700, #ff8c00)';
      premiumSection.classList.remove('premium-locked');
    } else {
      btn.textContent = 'Check Premium';
      tag.textContent = 'Universal Chat Bot — Free Tier';
      tag.style.background = 'var(--gradient)';
      premiumSection.classList.add('premium-locked');
    }
  });
}
